# Project of Project-Management-Course
- Using ESP8266 to control LED (IOT) 

- Using XAMPP to create a Webhost

- Link video : https://youtu.be/epzftL5Lr2I

- Arduino ESP8266 Board json : http://arduino.esp8266.com/stable/package_esp8266com_index.json
